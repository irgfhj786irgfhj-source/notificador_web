# Notificador Web (Push + Fallback con sonido)

## Requisitos
- Node.js 16 o superior.

## Instalar y ejecutar
```bash
npm install
npm start
```

Abre: http://localhost:3000

## Pasos en la web
1. **Activar notificaciones** y conceder permiso.
2. **Suscribirme a push** para registrar tu dispositivo.
3. **Enviar PUSH de prueba** para recibir una notificación.
4. **Mostrar ventana emergente con sonido** para el fallback cuando la página está abierta.

## Producción
- Despliega con **HTTPS** (requisito para Service Workers y Push).
- Persiste las suscripciones en una base de datos en lugar de memoria.
- Si apuntas a iOS, instala la web como PWA desde Safari (iOS 16.4+).
